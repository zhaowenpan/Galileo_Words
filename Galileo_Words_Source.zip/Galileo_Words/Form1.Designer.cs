﻿namespace Galileo_Words
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_Loop_Words_Native_Language = new System.Windows.Forms.ComboBox();
            this.comboBox_Loop_Words_Target_Language = new System.Windows.Forms.ComboBox();
            this.timer_Time = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label_Count = new System.Windows.Forms.Label();
            this.textBox2_Check_Words = new System.Windows.Forms.TextBox();
            this.textBox1_Check_Words = new System.Windows.Forms.TextBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Voice = new System.Windows.Forms.Button();
            this.button_Show = new System.Windows.Forms.Button();
            this.button_Word_Change = new System.Windows.Forms.Button();
            this.button_Next = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label_Timer = new System.Windows.Forms.Label();
            this.label_Times = new System.Windows.Forms.Label();
            this.textBox2_Loop_Word = new System.Windows.Forms.TextBox();
            this.textBox1_Loop_Word = new System.Windows.Forms.TextBox();
            this.button_Stop = new System.Windows.Forms.Button();
            this.button_Speak = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox_Loop_Words_Native_Language
            // 
            this.comboBox_Loop_Words_Native_Language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Loop_Words_Native_Language.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Loop_Words_Native_Language.FormattingEnabled = true;
            this.comboBox_Loop_Words_Native_Language.Location = new System.Drawing.Point(195, 44);
            this.comboBox_Loop_Words_Native_Language.Name = "comboBox_Loop_Words_Native_Language";
            this.comboBox_Loop_Words_Native_Language.Size = new System.Drawing.Size(676, 33);
            this.comboBox_Loop_Words_Native_Language.TabIndex = 20;
            this.comboBox_Loop_Words_Native_Language.SelectedIndexChanged += new System.EventHandler(this.comboBox_Loop_Words_Native_Language_SelectedIndexChanged);
            // 
            // comboBox_Loop_Words_Target_Language
            // 
            this.comboBox_Loop_Words_Target_Language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Loop_Words_Target_Language.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Loop_Words_Target_Language.FormattingEnabled = true;
            this.comboBox_Loop_Words_Target_Language.Location = new System.Drawing.Point(195, 5);
            this.comboBox_Loop_Words_Target_Language.Name = "comboBox_Loop_Words_Target_Language";
            this.comboBox_Loop_Words_Target_Language.Size = new System.Drawing.Size(676, 33);
            this.comboBox_Loop_Words_Target_Language.TabIndex = 20;
            this.comboBox_Loop_Words_Target_Language.SelectedIndexChanged += new System.EventHandler(this.comboBox_Loop_Words_Target_Language_SelectedIndexChanged);
            // 
            // timer_Time
            // 
            this.timer_Time.Interval = 1000;
            this.timer_Time.Tick += new System.EventHandler(this.timer_Time_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(22, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "Target Voice:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(23, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 25);
            this.label2.TabIndex = 23;
            this.label2.Text = "Native Voice:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tabPage3.Location = new System.Drawing.Point(4, 54);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1554, 650);
            this.tabPage3.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tabPage2.Controls.Add(this.label_Count);
            this.tabPage2.Controls.Add(this.textBox2_Check_Words);
            this.tabPage2.Controls.Add(this.textBox1_Check_Words);
            this.tabPage2.Controls.Add(this.button_Delete);
            this.tabPage2.Controls.Add(this.button_Voice);
            this.tabPage2.Controls.Add(this.button_Show);
            this.tabPage2.Controls.Add(this.button_Word_Change);
            this.tabPage2.Controls.Add(this.button_Next);
            this.tabPage2.Location = new System.Drawing.Point(4, 54);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1554, 650);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Check Words";
            // 
            // label_Count
            // 
            this.label_Count.AutoSize = true;
            this.label_Count.Font = new System.Drawing.Font("Arial Narrow", 40.2F);
            this.label_Count.Location = new System.Drawing.Point(1048, 492);
            this.label_Count.Name = "label_Count";
            this.label_Count.Size = new System.Drawing.Size(146, 64);
            this.label_Count.TabIndex = 34;
            this.label_Count.Text = "Count";
            // 
            // textBox2_Check_Words
            // 
            this.textBox2_Check_Words.Font = new System.Drawing.Font("Microsoft YaHei UI", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2_Check_Words.Location = new System.Drawing.Point(28, 36);
            this.textBox2_Check_Words.Multiline = true;
            this.textBox2_Check_Words.Name = "textBox2_Check_Words";
            this.textBox2_Check_Words.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox2_Check_Words.Size = new System.Drawing.Size(1490, 185);
            this.textBox2_Check_Words.TabIndex = 33;
            // 
            // textBox1_Check_Words
            // 
            this.textBox1_Check_Words.BackColor = System.Drawing.Color.White;
            this.textBox1_Check_Words.Font = new System.Drawing.Font("Arial Narrow", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1_Check_Words.ForeColor = System.Drawing.Color.Black;
            this.textBox1_Check_Words.Location = new System.Drawing.Point(26, 234);
            this.textBox1_Check_Words.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1_Check_Words.Name = "textBox1_Check_Words";
            this.textBox1_Check_Words.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1_Check_Words.Size = new System.Drawing.Size(1492, 118);
            this.textBox1_Check_Words.TabIndex = 32;
            // 
            // button_Delete
            // 
            this.button_Delete.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Delete.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Delete.Location = new System.Drawing.Point(652, 482);
            this.button_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(180, 80);
            this.button_Delete.TabIndex = 31;
            this.button_Delete.Text = "&Delete";
            this.button_Delete.UseVisualStyleBackColor = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Voice
            // 
            this.button_Voice.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Voice.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Voice.Location = new System.Drawing.Point(838, 482);
            this.button_Voice.Name = "button_Voice";
            this.button_Voice.Size = new System.Drawing.Size(180, 80);
            this.button_Voice.TabIndex = 30;
            this.button_Voice.Text = "&Voice";
            this.button_Voice.UseVisualStyleBackColor = false;
            this.button_Voice.Click += new System.EventHandler(this.button_Voice_Click);
            // 
            // button_Show
            // 
            this.button_Show.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Show.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Show.Location = new System.Drawing.Point(281, 482);
            this.button_Show.Name = "button_Show";
            this.button_Show.Size = new System.Drawing.Size(180, 80);
            this.button_Show.TabIndex = 29;
            this.button_Show.Text = "&Show";
            this.button_Show.UseVisualStyleBackColor = false;
            this.button_Show.Click += new System.EventHandler(this.button_Show_Click);
            // 
            // button_Word_Change
            // 
            this.button_Word_Change.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Word_Change.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Word_Change.Location = new System.Drawing.Point(95, 482);
            this.button_Word_Change.Name = "button_Word_Change";
            this.button_Word_Change.Size = new System.Drawing.Size(180, 80);
            this.button_Word_Change.TabIndex = 28;
            this.button_Word_Change.Text = "&Word1";
            this.button_Word_Change.UseVisualStyleBackColor = false;
            this.button_Word_Change.Click += new System.EventHandler(this.button_Word_Change_Click);
            // 
            // button_Next
            // 
            this.button_Next.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Next.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Next.Location = new System.Drawing.Point(467, 482);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(180, 80);
            this.button_Next.TabIndex = 27;
            this.button_Next.Text = "Check";
            this.button_Next.UseVisualStyleBackColor = false;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tabPage1.Controls.Add(this.label_Timer);
            this.tabPage1.Controls.Add(this.label_Times);
            this.tabPage1.Controls.Add(this.textBox2_Loop_Word);
            this.tabPage1.Controls.Add(this.textBox1_Loop_Word);
            this.tabPage1.Controls.Add(this.button_Stop);
            this.tabPage1.Controls.Add(this.button_Speak);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 54);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1554, 650);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Loop Words";
            // 
            // label_Timer
            // 
            this.label_Timer.AutoSize = true;
            this.label_Timer.BackColor = System.Drawing.Color.White;
            this.label_Timer.Font = new System.Drawing.Font("Arial Narrow", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Timer.Location = new System.Drawing.Point(369, 19);
            this.label_Timer.Name = "label_Timer";
            this.label_Timer.Size = new System.Drawing.Size(179, 57);
            this.label_Timer.TabIndex = 20;
            this.label_Timer.Text = "00:00:00";
            // 
            // label_Times
            // 
            this.label_Times.AutoSize = true;
            this.label_Times.BackColor = System.Drawing.Color.White;
            this.label_Times.Font = new System.Drawing.Font("Arial Narrow", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Times.ForeColor = System.Drawing.Color.Black;
            this.label_Times.Location = new System.Drawing.Point(656, 19);
            this.label_Times.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Times.Name = "label_Times";
            this.label_Times.Size = new System.Drawing.Size(148, 64);
            this.label_Times.TabIndex = 19;
            this.label_Times.Text = "Times";
            // 
            // textBox2_Loop_Word
            // 
            this.textBox2_Loop_Word.Font = new System.Drawing.Font("Arial Narrow", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2_Loop_Word.Location = new System.Drawing.Point(4, 354);
            this.textBox2_Loop_Word.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2_Loop_Word.Multiline = true;
            this.textBox2_Loop_Word.Name = "textBox2_Loop_Word";
            this.textBox2_Loop_Word.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2_Loop_Word.Size = new System.Drawing.Size(1510, 226);
            this.textBox2_Loop_Word.TabIndex = 18;
            // 
            // textBox1_Loop_Word
            // 
            this.textBox1_Loop_Word.Font = new System.Drawing.Font("Arial Narrow", 140.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1_Loop_Word.Location = new System.Drawing.Point(5, 110);
            this.textBox1_Loop_Word.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1_Loop_Word.Name = "textBox1_Loop_Word";
            this.textBox1_Loop_Word.Size = new System.Drawing.Size(1510, 222);
            this.textBox1_Loop_Word.TabIndex = 17;
            // 
            // button_Stop
            // 
            this.button_Stop.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Stop.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Stop.Location = new System.Drawing.Point(7, 11);
            this.button_Stop.Margin = new System.Windows.Forms.Padding(2);
            this.button_Stop.Name = "button_Stop";
            this.button_Stop.Size = new System.Drawing.Size(163, 86);
            this.button_Stop.TabIndex = 16;
            this.button_Stop.Text = "Stop";
            this.button_Stop.UseVisualStyleBackColor = false;
            this.button_Stop.Click += new System.EventHandler(this.button_Stop_Click);
            // 
            // button_Speak
            // 
            this.button_Speak.BackColor = System.Drawing.Color.Gainsboro;
            this.button_Speak.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.button_Speak.Location = new System.Drawing.Point(179, 11);
            this.button_Speak.Margin = new System.Windows.Forms.Padding(2);
            this.button_Speak.Name = "button_Speak";
            this.button_Speak.Size = new System.Drawing.Size(174, 86);
            this.button_Speak.TabIndex = 15;
            this.button_Speak.Text = "Sepak";
            this.button_Speak.UseVisualStyleBackColor = false;
            this.button_Speak.Click += new System.EventHandler(this.button_Speak_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(200, 50);
            this.tabControl1.Location = new System.Drawing.Point(4, 83);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1562, 708);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1590, 756);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_Loop_Words_Native_Language);
            this.Controls.Add(this.comboBox_Loop_Words_Target_Language);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Galileo_Words";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBox_Loop_Words_Native_Language;
        private System.Windows.Forms.ComboBox comboBox_Loop_Words_Target_Language;
        private System.Windows.Forms.Timer timer_Time;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label_Count;
        private System.Windows.Forms.TextBox textBox2_Check_Words;
        private System.Windows.Forms.TextBox textBox1_Check_Words;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Voice;
        private System.Windows.Forms.Button button_Show;
        private System.Windows.Forms.Button button_Word_Change;
        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label_Timer;
        private System.Windows.Forms.Label label_Times;
        private System.Windows.Forms.TextBox textBox2_Loop_Word;
        private System.Windows.Forms.TextBox textBox1_Loop_Word;
        private System.Windows.Forms.Button button_Stop;
        private System.Windows.Forms.Button button_Speak;
        private System.Windows.Forms.TabControl tabControl1;
    }
}

