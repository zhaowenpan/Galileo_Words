﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Reflection.Emit;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Galileo_Words
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static System.Speech.Synthesis.SpeechSynthesizer ControlPanel_Voices;
        string target_Voice = "";
        string native_Voice = "";
        DateTime time_start;
        DateTime time_now;
        TimeSpan ts;
        string ts_string;
        int Wordscounter = 0;
        String ListTextFile2_String = "";
        String[] Word1_ArrayString = new String[50000];
        String[] Word2_ArrayString = new String[50000];
        string[] voice_name;
        string target_Voice_Name;
        string native_Voice_Name;
        bool SpeakAsync_word1_done = false;
        bool SpeakAsync_word2_done = false;
        bool SpeakAsync_Separate_word1_done = false;
        String word1 = "";
        String word2 = "";
        int Speak_Rate_word1_i = 0;
        int Speak_Rate_word2_i = 0;
        int Speak_Rate_Separate_word1_i = 0; //-3;
        bool Speak_toStop = false;
        bool Voice_toStop = false;  
        bool Remembering = false;
        int word_List_index_i = -1;
        List<string> word1_List = new List<string>();
        List<string> word2_List = new List<string>();
        int index_i = -1;
        string Languages_file = "Target_Native_Languages.txt";
        string Word_List_file = "words.txt";
        private void Form1_Load(object sender, EventArgs e)
        {
            //this.ControlBox = false;
            ControlPanel_Voices = new System.Speech.Synthesis.SpeechSynthesizer();
            foreach (var voice in ControlPanel_Voices.GetInstalledVoices())
            {
                var info = voice.VoiceInfo;
                comboBox_Loop_Words_Target_Language.Items.Add(info.Description);
                comboBox_Loop_Words_Native_Language.Items.Add(info.Description);
            }
            
            if (File.Exists(Languages_file))
            {
                string content = File.ReadAllText(Languages_file);
                string[] languages = content.Split('|');
                comboBox_Loop_Words_Target_Language.Text = languages[0];
                comboBox_Loop_Words_Native_Language.Text = languages[1];
            }
            else
            {
                comboBox_Loop_Words_Target_Language.Text = "Select Target Language Voice";
                comboBox_Loop_Words_Native_Language.Text = "Select Native Language Voice";
            }
        }
        private void comboBox_Loop_Words_Target_Language_SelectedIndexChanged(object sender, EventArgs e)
        {
            write_Target_Native_Languages_file();
        }

        private void comboBox_Loop_Words_Native_Language_SelectedIndexChanged(object sender, EventArgs e)
        {
            write_Target_Native_Languages_file();
        }
        private void write_Target_Native_Languages_file()
        {
            string contentToWrite = comboBox_Loop_Words_Target_Language.Text + "|" + comboBox_Loop_Words_Native_Language.Text;
            File.WriteAllText(Languages_file, contentToWrite);
        }
        private void button_Speak_Click(object sender, EventArgs e)
        {
            if (comboBox_Loop_Words_Target_Language.Text.Trim() == "Select Target Language Voice")
            {
                MessageBox.Show("Select Target Language Voice");
                return;
            }
            if (comboBox_Loop_Words_Target_Language.Text.Trim() == "")
            {
                MessageBox.Show("Target Language Voice is empty, Please select Target Language Voice");
                return;
            }
            //--------------------------
            if (comboBox_Loop_Words_Native_Language.Text.Trim() == "Select Native Language Voice")
            {
                MessageBox.Show("Select Target Language Voice");
                return;
            }
            if (comboBox_Loop_Words_Native_Language.Text.Trim() == "")
            {
                MessageBox.Show("Native Language Voice is empty, Please select Native Language Voice");
                return;
            }
            //---------------------

            if (comboBox_Loop_Words_Target_Language.Text.Trim() == comboBox_Loop_Words_Native_Language.Text.Trim())
            {
                MessageBox.Show("Target and Native Language can be same");
                return;
            }


            target_Voice = comboBox_Loop_Words_Target_Language.Text;
            native_Voice = comboBox_Loop_Words_Native_Language.Text;
            ReadAloud_Asynchronous();

        }
        private void ReadAloud_Asynchronous()
        {
            time_start = DateTime.Now;
            timer_Time.Interval = 1000;
            timer_Time.Enabled = true;
            GetWordsFromTextFiles();
            Speak_toStop = false;
            Random ran = new Random();
            int n;

            int i = 0;
            while (true)
            {
                if (Speak_toStop == true) break;
                Application.DoEvents();
                n = ran.Next(0, Wordscounter);
                label_Times.Text = (i + 1).ToString() + "/" + Wordscounter.ToString();
                word1 = Word1_ArrayString[n];
                word2 = Word2_ArrayString[n];
                textBox1_Loop_Word.Text = word1;
                textBox2_Loop_Word.Text = word2;

                voice_name = target_Voice.Split('-');
                target_Voice_Name = voice_name[0].ToString().Trim();
                voice_name = native_Voice.Split('-');
                native_Voice_Name = voice_name[0].ToString().Trim();

                ControlPanel_Voices.SelectVoice(target_Voice_Name);
                if (Speak_toStop == true) break;
                SpeakAsync_word1_done = false;
                ControlPanel_Voices.SpeakAsync(word1);
                ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (Speak_toStop == true) break;
                    Application.DoEvents();
                }
                if (Speak_toStop == true) break;
                SpeakAsync_word1_done = false;
                ControlPanel_Voices.SpeakAsync(word1);
                ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (Speak_toStop == true) break;
                    Application.DoEvents();
                }

                if (Speak_toStop == true) break;
                //_DesktopSpeechSynthesizer.Rate = Speak_Rate_Separate_word1_i;
                SpeakAsync_Separate_word1_done = false;
                ControlPanel_Voices.SpeakAsync(Separate_word(word1));
                ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_Separate_word1);
                while (SpeakAsync_Separate_word1_done == false)
                {
                    if (Speak_toStop == true) break;
                    Application.DoEvents();
                }
                if (Speak_toStop == true) break;
                SpeakAsync_word1_done = false;
                ControlPanel_Voices.SpeakAsync(word1);
                ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (Speak_toStop == true) break;
                    Application.DoEvents();
                }

                if (Speak_toStop == true) break;
                ControlPanel_Voices.SelectVoice(native_Voice_Name);
                SpeakAsync_word2_done = false;
                ControlPanel_Voices.SpeakAsync(word2);
                ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word2);
                while (SpeakAsync_word2_done == false)
                {
                    if (Speak_toStop == true) break;
                    Application.DoEvents();
                }
                i = i + 1;

            }



            timer_Time.Enabled = false;
        }
        //////////////////////////////////////////////////////////////////////////////////////
        private String Separate_word(String w)
        {
            int len = 0;
            w = w.Trim();
            len = w.Length;
            String sw = "";
            for (int i = 0; i < len; i++)
            {
                sw = sw + w.Substring(i, 1) + "..................";
            }
            sw = sw.TrimEnd();
            return sw;
        }
        private void SpeakCompleted_word1(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_word1_done = true;
        }
        private void SpeakCompleted_Separate_word1(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_Separate_word1_done = true;
        }
        private void SpeakCompleted_word2(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_word2_done = true;
        }
        //////////////////////////////////////////////////////////////////////////////////////
        private void GetWordsFromTextFiles()
        {
            // Read the file and display it line by line.  
            Wordscounter = 0;
            int i = 0;
            int indexof = 0;
            string line = "";
            string line1 = "";
            string line2 = "";
            //System.IO.StreamReader file = new System.IO.StreamReader(@"D:\0Source\Sleeping_Words\Sleeping_Words\Words_New.txt");
            System.IO.StreamReader file = new System.IO.StreamReader(Word_List_file);
            word1_List.Clear();
            word2_List.Clear();

            while ((line = file.ReadLine()) != null)
            {
                indexof = 0;
                indexof = line.IndexOf("|");
                line1 = line.Substring(0, indexof);
                line2 = line.Substring(indexof + 1);
                Word1_ArrayString[i] = line1;
                Word2_ArrayString[i] = line2;
                word1_List.Add(line1.Trim());
                word2_List.Add(line2.Trim());
                i++;
                Wordscounter++;
            }
            label_Count.Text = Wordscounter.ToString();
            file.Close();
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void timer_Time_Tick(object sender, EventArgs e)
        {
            time_now = DateTime.Now;
            ts = time_now - time_start;
            ts_string = ts.ToString();
            ts_string = ts_string.Substring(0, 8);
            label_Timer.Text = ts_string;
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            Speak_toStop = true;
        }

        private void button_Word_Change_Click(object sender, EventArgs e)
        {
            if (Remembering == true) return;
            if (button_Word_Change.Text == "&Word1")
            {
                button_Word_Change.Text = "&Word2";
                textBox1_Check_Words.Visible = false;
                textBox2_Check_Words.Visible = true;
            }
            else
            {
                button_Word_Change.Text = "&Word1";
                textBox1_Check_Words.Visible = true;
                textBox2_Check_Words.Visible = false;  
            }
        }

        private void button_Show_Click(object sender, EventArgs e)
        {
            textBox1_Check_Words.Visible = true;
            textBox2_Check_Words.Visible = true;
        }

        private void button_Next_Click(object sender, EventArgs e)
        {
            if (Remembering == true) return;
            GetWordsFromTextFiles();
            Next_Word();
        }
        private void Next_Word()
        {
            //MessageBox.Show(Wordscounter.ToString());
            if (Wordscounter < 1)
            {
                textBox1_Check_Words.Text = "";
                textBox2_Check_Words.Text = "";
                MessageBox.Show("No word");
                return;
            }
            textBox1_Check_Words.Visible = true;
            textBox2_Check_Words.Visible = false;
            word_List_index_i = word_List_index_i + 1;
            if (word_List_index_i >= Wordscounter)
            {
                word_List_index_i = -1;
                index_i = word_List_index_i;
                textBox1_Check_Words.Text = "";
                textBox2_Check_Words.Text = "";
                button_Next.Text = "Check";

                return;
            }
            index_i = word_List_index_i;
            textBox1_Check_Words.Text = word1_List[index_i].ToString();
            textBox2_Check_Words.Text = word2_List[index_i].ToString();
            
            if (button_Next.Text == "Check") button_Next.Text = "&Next";

        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (label_Count.Text == "0") return;
            if (Remembering == true) return;
            if (index_i > -1)
            {
                //MessageBox.Show("1 |" +index_i.ToString());
                //MessageBox.Show(index_i.ToString());
                word1_List.RemoveAt(index_i);
                word2_List.RemoveAt(index_i);
                Wordscounter = word1_List.Count;

                //MessageBox.Show(Wordscounter.ToString());
                //return;
                label_Count.Text = Wordscounter.ToString();
                label_Count.Refresh();
                StreamWriter writer = new StreamWriter(Word_List_file);
                for (int i = 0; i < Wordscounter; i++)
                {
                    writer.WriteLine(word1_List[i] + "|" + word2_List[i]);
                }
                writer.Close();
                index_i = index_i - 1;
                word_List_index_i = index_i;
                Next_Word();
            }
        }

        private void button_Voice_Click(object sender, EventArgs e)
        {

            Voice_toStop = false;
            if (Remembering == true) return;
            if (textBox1_Check_Words.Text.Trim().Length == 0) { return; }
            if (textBox2_Check_Words.Text.Trim().Length == 0) { return; }
            target_Voice = comboBox_Loop_Words_Target_Language.Text;
            native_Voice = comboBox_Loop_Words_Native_Language.Text;
            voice_name = target_Voice.Split('-');
            target_Voice_Name = voice_name[0].ToString().Trim();
            voice_name = native_Voice.Split('-');
            native_Voice_Name = voice_name[0].ToString().Trim();
            word1 = textBox1_Check_Words.Text.Trim();
            word2 = textBox2_Check_Words.Text.Trim();
            SpeakAsync_word1_done = false;
            SpeakAsync_word2_done = false;
            SpeakAsync_Separate_word1_done = false;
            ControlPanel_Voices = new System.Speech.Synthesis.SpeechSynthesizer();
            //ControlPanel_Voices.SetOutputToDefaultAudioDevice();
            ControlPanel_Voices.SelectVoice(target_Voice_Name);
            ControlPanel_Voices.Rate = Speak_Rate_word1_i;
            SpeakAsync_word1_done = false;
            ControlPanel_Voices.SpeakAsync(word1);
            ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
            while (SpeakAsync_word1_done == false)
            {
                if (Voice_toStop == true) break;
                Application.DoEvents();
            }
            ControlPanel_Voices.Rate = Speak_Rate_word1_i;
            SpeakAsync_word1_done = false;
            ControlPanel_Voices.SpeakAsync(word1);
            ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
            while (SpeakAsync_word1_done == false)
            {
                if (Voice_toStop == true) break;
                Application.DoEvents();
            }
            ControlPanel_Voices.Rate = Speak_Rate_Separate_word1_i;
            SpeakAsync_Separate_word1_done = false;
            ControlPanel_Voices.SpeakAsync(Separate_word(word1));
            ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_Separate_word1);
            while (SpeakAsync_Separate_word1_done == false)
            {
                if (Voice_toStop == true) break;
                Application.DoEvents();
            }

            ControlPanel_Voices.Rate = Speak_Rate_word1_i;
            SpeakAsync_word1_done = false;
            ControlPanel_Voices.SpeakAsync(word1);
            ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
            while (SpeakAsync_word1_done == false)
            {
                if (Voice_toStop == true) break;
                Application.DoEvents();
            }

            /////*****************************************************************************
            ControlPanel_Voices = new System.Speech.Synthesis.SpeechSynthesizer();
            //ControlPanel_Voices.SetOutputToDefaultAudioDevice();
            ControlPanel_Voices.SelectVoice(native_Voice_Name);
            ControlPanel_Voices.Rate = Speak_Rate_word2_i;
            SpeakAsync_word2_done = false;
            ControlPanel_Voices.SpeakAsync(word2);
            ControlPanel_Voices.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word2);
            while (SpeakAsync_word2_done == false)
            {
                if (Voice_toStop == true) break;
                Application.DoEvents();
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Speak_toStop = true;
            //Voice_toStop = true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Exit_Application();
        }
        private void Exit_Application()
        {
            write_Target_Native_Languages_file();
            Speak_toStop = true;
            Voice_toStop = true;
            Speak_toStop = true;
            System.Windows.Forms.Application.Exit();
        }
    }
}
